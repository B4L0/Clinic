create FUNCTION policz(id VARCHAR2) RETURN NUMBER 
IS
CURSOR c_tmp IS SELECT COUNT(*) l_zal FROM zaliczenia WHERE wykladowca_id = id;
tmp number:=0;
BEGIN
	FOR z_tmp IN  c_tmp LOOP
	tmp:=z_tmp.l_zal;
	END LOOP;
	RETURN tmp;
END policz;
/

