create PROCEDURE Dodaj_Przedmiot(
    przedmiot_id przedmioty.przedmiot_id%TYPE,
    nazwa przedmioty.nazwa%TYPE,
    opis przedmioty.opis%TYPE,
    rodzaj przedmioty.rodzaj%TYPE,
    ects przedmioty.ects%TYPE)
IS
BEGIN
    INSERT INTO PRZEDMIOTY VALUES (przedmiot_id, nazwa, opis, rodzaj, ects);
    COMMIT;
END;



BEGIN
    Dodaj_Przedmiot(10, 'Matematyka dyskretna', 'Opis matematyki dyskretnej...', 'Ćwiczenia', 50);
END;
/

